throw new Error('Resource loading must never execute package hooks');
